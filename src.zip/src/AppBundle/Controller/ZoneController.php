<?php

namespace AppBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\HttpFoundation\Request;
use AppBundle\Utils\Coords;
use AppBundle\Utils\generateSamples;
use AppBundle\Entity\Zone;
use Symfony\Component\HttpFoundation\Session\Session;



class ZoneController extends Controller
{
	
	private static $zones;
	private static $nb;
	
	public function __construct(){
		
		
	}
	
    /**
     * @Route("/createZone")
     */
    public function createZoneAction()
    {
		
		$session = new Session();
	
		if(!$session->has('indice')) $session->set('indice',0);
		if(!$session->has('samples')) $session->set('samples',generateSamples::getInstance()->getZones());
		
		$zones = $session->get('samples');
		$indice = $session->get('indice');
		$zone = $zones[$indice];
	
		$em = $this->getDoctrine()->getEntityManager();
		$em->persist($zone);
		$em->flush();
		
		$indice++;
		$session->set('indice',$indice);
		
		
        return $this->render('AppBundle:Zone:create_zone.html.twig', array(
    
			'zone' => $zone,
        ));
    }

    /**
     * @Route("/getZones")
     */
    public function getZonesAction()
    {
		$zones = $this->getDoctrine()->getRepository('AppBundle:Zone')->findAll();
		
        return $this->render('AppBundle:Zone:get_zones.html.twig', array(
            'zones' => $zones,
        ));
    }

    /**
     * @Route("/getZone/{name}")
     */
    public function getZoneAction(Request $request)
    {
		$zone = $this->getDoctrine()->getRepository('AppBundle:Zone')->findOneByNom($request->get('name'));
        return $this->render('AppBundle:Zone:get_zone.html.twig', array(
            'zone' => $zone,
        ));
    }

    /**
     * @Route("/modifyZone/{name}")
     */
    public function modifyZoneAction(Request $request)
    {
		
		$gd = $this->getDoctrine();
		$zone = $gd->getRepository('AppBundle:Zone')->findOneByNom($request->get('name'));
		$zone = (Object)$zone;
		var_dump($zone);
		if (!$zone) {
        throw $this->createNotFoundException(
            'No product found for name '.$name
        );
		}
		
		$polygone = array();
			
		for($j = 0,$jl = rand(3,generateSamples::NB_POINTS_MAX) ; $j < $jl; $j++){
			
			$x = rand(0,generateSamples::XMAX);
			$y = rand(0,generateSamples::YMAX);
			$c = new Coords($x,$y);
			array_push($polygone,$c);
		}
		
		
		$zone.setPolygone($polygone);
		
		$em = $gd->getEntityManager();
		$em->persist($zone);
		$em->flush();
		
        return $this->render('AppBundle:Zone:modify_zone.html.twig', array(
            
			'zone' => $zone,
        ));
    }

    /**
     * @Route("/deleteZone/{name}")
     */
    public function deleteZoneAction(Request $request)
    {
		$name = $request->get('name');
		$zone = $this->getDoctrine()->getRepository('AppBundle:Zone')->findOneByNom($name);
		
		$em = $this->getDoctrine()->getEntityManager();
		$em->remove($zone);
		$em->flush();
		
        return $this->render('AppBundle:Zone:delete_zone.html.twig', array(
            
			'name' => $name,
        ));
    }

}


