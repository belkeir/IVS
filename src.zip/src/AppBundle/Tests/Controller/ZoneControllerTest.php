<?php

namespace AppBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class ZoneControllerTest extends WebTestCase
{
    public function testCreatezone()
    {
        $client = static::createClient();

        $crawler = $client->request('GET', '/createZone');
    }

    public function testGetzones()
    {
        $client = static::createClient();

        $crawler = $client->request('GET', '/getZones');
    }

    public function testGetzone()
    {
        $client = static::createClient();

        $crawler = $client->request('GET', '/getZone');
    }

    public function testModifyzone()
    {
        $client = static::createClient();

        $crawler = $client->request('GET', '/modifyZone');
    }

    public function testDeletezone()
    {
        $client = static::createClient();

        $crawler = $client->request('GET', '/deleteZone');
    }

}
