<?php

namespace AppBundle\Utils;

use AppBundle\Entity\Zone;
use AppBundle\Utils\Coords;


class generateSamples{
	
	const NB_IN = 20; // Nombre de valeurs fictives générées maximales
	const XMAX = 1200; // Coordonnée X maximale
	const YMAX = 1200; // Coordonnée Y maximale
	const NB_POINTS_MAX = 10; // Le polynome est décrit avec 10 points au maximum
	
	private static $zones;
	private static $instance;
	private static $nb;
	
	private function __construct(){
		
		self::$nb = 0;
		self::$zones = array();
		
		// Creation de la liste d'acquisition de zones simulées
		for($i = 0 ; $i < self::NB_IN ; $i++){
			
			$nom = 'nom'.$i;
			//echo '<br/>valeur de i : '.$i.' nom : '.$nom.'<br/>';
			$couleur = RandomCouleur();
			$polygone = array();
			
			for($j = 0,$jl = rand(3,self::NB_POINTS_MAX) ; $j < $jl; $j++){
				
				$x = rand(0,self::XMAX);
				$y = rand(0,self::YMAX);
				$c = new Coords($x,$y);
				array_push($polygone,$c);
			}
			
			$zone = new Zone();
			$zone->setNom($nom);
			$zone->setCouleur($couleur);
			$zone->setPolygone($polygone);
			
			array_push(self::$zones,$zone);
		}
		
		
		
	}
	
	public static function getInstance(){
		
		if(is_null(self::$instance)){
			self::$instance = new generateSamples();
			return self::$instance;
			
		}else{
			
			return self::$instance;
			
		}
		
	}
	
	public function getSample(){
		
	
		if(self::$nb < self::NB_IN){
			
			return self::$zones[self::$nb];
			self::$nb++;
			
		}
		else{
			
			return self::$zones[self::NB_IN - 1];
			
		}
		
		
	}
	
	public function getNB(){
		
		return self::$nb;
	}
	
	public function getZones(){
		
		return self::$zones;
		
	}
	
	
}


function RandomCouleur(){
 
$r=dechex(rand(0,255));
$v=dechex(rand(0,255));
$b=dechex(rand(0,255));
 
return "#".$r.$v.$b;
 
}


